export default {
    en: {}
};
